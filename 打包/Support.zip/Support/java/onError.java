package Support;

public abstract interface onError
{
	public abstract void onError(Throwable e,String Void,Class<?> c);
}
