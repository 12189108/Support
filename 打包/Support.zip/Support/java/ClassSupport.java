package Support;

public class ClassSupport
{
	protected onError error;
	public void setErrorListener(onError error){
		this.error=error;
	}
} 
