package Support.PluginSupport;
import Support.*;
import android.os.*;

public class PluginActivity extends BaseActivity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
	}
	
}
